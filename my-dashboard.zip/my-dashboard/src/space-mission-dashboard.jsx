import React, { useState } from "react";
import {
  BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid,
  Tooltip, ResponsiveContainer, AreaChart, Area,
} from "recharts";

// ---------- design tokens (mirrors the notebook's own space-mission palette) ----------
const T = {
  bg: "#070B14",
  surface: "#0F1521",
  surfaceRaised: "#141C2C",
  border: "#232C3F",
  textPrimary: "#EDF1F7",
  textSecondary: "#8C97AC",
  textMuted: "#5C6577",
  blue900: "#0B3D91",
  blue700: "#145DA0",
  blue500: "#1E88E5",
  blue300: "#42A5F5",
  blue100: "#90CAF9",
  amber: "#F3A73B",
  coral: "#E8735C",
};

// ---------- exact figures pulled from the notebook's stored cell outputs ----------
const TOTAL_MISSIONS = 4324;
const YEARS_SPANNED = "1957–2020";

const missionStatusDetailed = [
  { name: "Success", value: 89.71 },
  { name: "Failure", value: 7.84 },
  { name: "Partial failure", value: 2.36 },
  { name: "Prelaunch failure", value: 0.09 },
];
const missionStatusSimple = [
  { name: "Success", value: 89.71 },
  { name: "Failure", value: 10.29 },
];

const topOrgs = [
  { name: "RVSN USSR", launches: 1777 },
  { name: "Arianespace", launches: 279 },
  { name: "CASC", launches: 251 },
  { name: "General Dynamics", launches: 251 },
  { name: "NASA", launches: 203 },
];

const topYears = [
  { year: "1971", missions: 119 }, { year: "2018", missions: 117 },
  { year: "1977", missions: 114 }, { year: "1975", missions: 113 },
  { year: "1976", missions: 113 }, { year: "2019", missions: 109 },
  { year: "1970", missions: 107 }, { year: "1967", missions: 106 },
  { year: "1973", missions: 103 }, { year: "1968", missions: 103 },
].reverse();

const rocketStatus = [
  { name: "Retired", value: 3534 },
  { name: "Active", value: 790 },
];

// exact bar values read off the "Top 10 Launch Countries" chart
const topCountries = [
  { name: "Russia", launches: 1400 }, { name: "USA", launches: 1345 },
  { name: "Kazakhstan", launches: 700 }, { name: "France", launches: 305 },
  { name: "China", launches: 270 }, { name: "Japan", launches: 125 },
  { name: "India", launches: 76 }, { name: "Pacific Ocean", launches: 30 },
  { name: "New Zealand", launches: 15 }, { name: "Iran", launches: 10 },
].reverse();

// exact counts read off the "Launch Volume: Top 10 Organisations x Decade" heatmap
const decades = ["1950", "1960", "1970", "1980", "1990", "2000", "2010", "2020"];
const orgDecadeHeatmap = [
  { org: "RVSN USSR", counts: [11, 439, 814, 436, 77, 0, 0, 0] },
  { org: "Arianespace", counts: [0, 0, 0, 25, 88, 68, 94, 4] },
  { org: "CASC", counts: [0, 1, 16, 15, 39, 53, 108, 19] },
  { org: "General Dynamics", counts: [1, 133, 55, 42, 20, 0, 0, 0] },
  { org: "NASA", counts: [3, 54, 10, 32, 64, 34, 6, 0] },
  { org: "VKS RF", counts: [0, 0, 0, 0, 104, 52, 42, 3] },
  { org: "US Air Force", counts: [12, 119, 26, 4, 0, 0, 0, 0] },
  { org: "ULA", counts: [0, 0, 0, 0, 0, 37, 99, 4] },
  { org: "Boeing", counts: [0, 0, 0, 5, 85, 46, 0, 0] },
  { org: "Martin Marietta", counts: [0, 13, 52, 32, 17, 0, 0, 0] },
];
const heatMax = Math.max(...orgDecadeHeatmap.flatMap((r) => r.counts));

// exact values read off the correlation heatmap
const corrLabels = ["Year", "Price", "Mission_Success"];
const corrMatrix = [
  [1.0, -0.38, 0.15],
  [-0.38, 1.0, 0.10],
  [0.15, 0.10, 1.0],
];

// closely read off the "Number of Space Missions Over Time" line chart (exact where a year matches the busiest-years table above)
const yearlyTrend = [
  3,8,28,20,45,82,41,62,88,105,106,103,105,107,119,101,103,98,113,113,114,96,49,
  55,68,70,65,74,68,60,57,52,80,62,61,63,62,60,63,69,65,57,56,44,51,52,38,41,48,
  49,50,48,38,42,45,53,53,91,90,92,105,117,109,64,
].map((v, i) => ({ year: String(1957 + i), missions: v }));

// approximate % share per decade, read off the "Global Space Launch Share by Decade" stacked chart
const countryDecadeShare = [
  { decade: "1950", Russia: 0, USA: 78, Kazakhstan: 22, France: 0, China: 0, Japan: 0 },
  { decade: "1960", Russia: 22, USA: 42, Kazakhstan: 34, France: 1, China: 0, Japan: 1 },
  { decade: "1970", Russia: 60, USA: 15, Kazakhstan: 21, France: 1, China: 1, Japan: 2 },
  { decade: "1980", Russia: 57, USA: 19, Kazakhstan: 12, France: 5, China: 2, Japan: 5 },
  { decade: "1990", Russia: 24, USA: 45, Kazakhstan: 7, France: 15, China: 6, Japan: 3 },
  { decade: "2000", Russia: 14, USA: 46, Kazakhstan: 6, France: 16, China: 13, Japan: 5 },
  { decade: "2010", Russia: 9, USA: 38, Kazakhstan: 10, France: 17, China: 20, Japan: 6 },
  { decade: "2020", Russia: 5, USA: 37, Kazakhstan: 10, France: 4, China: 39, Japan: 5 },
];
const shareKeys = ["Russia", "USA", "Kazakhstan", "France", "China", "Japan"];
const shareColors = { Russia: T.blue900, USA: "#8B85F0", Kazakhstan: T.blue500, France: "#1D9E75", China: "#5DCAA5", Japan: T.blue100 };

// approximate counts, read off "India's Mission Outcomes by Decade"
const indiaDecade = [
  { decade: "1970", Failure: 1, "Partial failure": 0, Success: 0 },
  { decade: "1980", Failure: 2, "Partial failure": 1, Success: 3 },
  { decade: "1990", Failure: 1, "Partial failure": 1, Success: 4 },
  { decade: "2000", Failure: 1, "Partial failure": 2, Success: 13 },
  { decade: "2010", Failure: 3, "Partial failure": 0, Success: 44 },
];

const STATUS_COLORS = { Success: T.blue300, Failure: T.coral, "Partial failure": T.amber, "Prelaunch failure": T.blue100, Retired: T.blue700, Active: T.blue300 };

function fmtPct(v) { return v.toFixed(1) + "%"; }
function heatColor(v) {
  const t = v / heatMax;
  return [T.blue900, T.blue700, T.blue500, T.blue300, T.blue100][Math.min(4, Math.floor(t * 5))] || T.surfaceRaised;
}
function corrColor(v) {
  const a = Math.abs(v);
  if (v === 1) return T.blue900;
  return a > 0.3 ? T.blue700 : a > 0.15 ? T.blue500 : T.surfaceRaised;
}

const cardTitle = { fontSize: 13.5, fontWeight: 500, marginBottom: 4 };
const cardSub = { fontSize: 12, color: T.textMuted, marginBottom: 10 };

export default function SpaceMissionDashboard() {
  const [statusView, setStatusView] = useState("detailed");
  const statusData = statusView === "detailed" ? missionStatusDetailed : missionStatusSimple;

  const kpis = [
    { label: "Total missions", value: TOTAL_MISSIONS.toLocaleString(), sub: YEARS_SPANNED },
    { label: "Success rate", value: "89.7%", sub: "10.3% failure (all types)" },
    { label: "Active rockets", value: "790", sub: "18.3% of rocket types" },
    { label: "Price disclosed", value: "22.3%", sub: "mostly commercial launches" },
  ];

  const segBtn = (active) => ({
    background: active ? T.blue900 : "transparent", color: active ? "#fff" : T.textSecondary,
    border: `1px solid ${active ? T.blue700 : T.border}`, borderRadius: 7, padding: "6px 12px",
    fontSize: 12, fontFamily: "'JetBrains Mono', monospace", cursor: "pointer",
  });

  return (
    <div style={{ background: T.bg, color: T.textPrimary, fontFamily: "'Inter', -apple-system, sans-serif", padding: "28px 28px 36px", minHeight: "100%", width: "100%", boxSizing: "border-box" }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@500;600&family=Inter:wght@400;500;600&family=JetBrains+Mono:wght@400;500&display=swap');
        * { box-sizing: border-box; }
        .card { background: ${T.surface}; border: 1px solid ${T.border}; border-radius: 12px; }
        .mono { font-family: 'JetBrains Mono', monospace; }
        table { border-collapse: collapse; width: 100%; }
        th, td { text-align: center; padding: 6px 4px; font-size: 11px; }
        th { color: ${T.textMuted}; font-weight: 500; }
        td.rowlabel, th.rowlabel { text-align: left; color: ${T.textSecondary}; font-size: 11px; padding-right: 8px; white-space: nowrap; }
      `}</style>

      {/* header */}
      <div style={{ marginBottom: 22 }}>
        <div style={{ fontSize: 11, letterSpacing: "0.12em", color: T.blue300, textTransform: "uppercase", marginBottom: 6, fontFamily: "'JetBrains Mono', monospace" }}>
          Space mission market intelligence
        </div>
        <h1 style={{ fontFamily: "'Space Grotesk', sans-serif", fontSize: 25, fontWeight: 600, margin: 0 }}>
          63 years of global launch history
        </h1>
        <div style={{ color: T.textMuted, fontSize: 13, marginTop: 4, maxWidth: 640 }}>
          Who launches, who succeeds, and what it costs — {TOTAL_MISSIONS.toLocaleString()} missions, {YEARS_SPANNED}
        </div>
      </div>

      {/* kpi row */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(170px, 1fr))", gap: 14, marginBottom: 16 }}>
        {kpis.map((k) => (
          <div key={k.label} className="card" style={{ padding: "16px 18px" }}>
            <div style={{ fontSize: 11.5, color: T.textMuted, marginBottom: 8 }}>{k.label}</div>
            <div className="mono" style={{ fontSize: 22, fontWeight: 500 }}>{k.value}</div>
            <div style={{ fontSize: 11, color: T.textSecondary, marginTop: 4 }}>{k.sub}</div>
          </div>
        ))}
      </div>

      {/* yearly trend, full width */}
      <div className="card" style={{ padding: "18px 20px 8px", marginBottom: 14 }}>
        <div style={cardTitle}>Missions over time</div>
        <div style={cardSub}>Annual mission count, 1957–2020 (2020 is a partial year)</div>
        <ResponsiveContainer width="100%" height={220}>
          <AreaChart data={yearlyTrend} margin={{ left: -20, right: 10, top: 5, bottom: 0 }}>
            <defs>
              <linearGradient id="yr" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor={T.blue300} stopOpacity={0.35} />
                <stop offset="100%" stopColor={T.blue300} stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid stroke={T.border} vertical={false} />
            <XAxis dataKey="year" tick={{ fill: T.textMuted, fontSize: 10 }} axisLine={{ stroke: T.border }} tickLine={false} interval={4} />
            <YAxis tick={{ fill: T.textMuted, fontSize: 11 }} axisLine={false} tickLine={false} />
            <Tooltip contentStyle={{ background: T.surfaceRaised, border: `1px solid ${T.border}`, borderRadius: 8, fontSize: 12 }} />
            <Area type="monotone" dataKey="missions" stroke={T.blue300} strokeWidth={2} fill="url(#yr)" />
          </AreaChart>
        </ResponsiveContainer>
      </div>

      {/* mission status + rocket status */}
      <div style={{ display: "grid", gridTemplateColumns: "1.3fr 1fr", gap: 14, marginBottom: 14 }}>
        <div className="card" style={{ padding: "18px 20px 10px" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <div style={cardTitle}>Mission outcomes</div>
            <div style={{ display: "flex", gap: 6 }}>
              <button style={segBtn(statusView === "detailed")} onClick={() => setStatusView("detailed")}>Detailed</button>
              <button style={segBtn(statusView === "simple")} onClick={() => setStatusView("simple")}>Grouped</button>
            </div>
          </div>
          <div style={cardSub}>Share of all {TOTAL_MISSIONS.toLocaleString()} missions</div>
          <div style={{ display: "flex", alignItems: "center", gap: 20 }}>
            <ResponsiveContainer width={170} height={170}>
              <PieChart>
                <Pie data={statusData} dataKey="value" nameKey="name" innerRadius={44} outerRadius={72} paddingAngle={2}>
                  {statusData.map((d, i) => <Cell key={i} fill={STATUS_COLORS[d.name] || T.blue300} stroke={T.surface} strokeWidth={2} />)}
                </Pie>
                <Tooltip contentStyle={{ background: T.surfaceRaised, border: `1px solid ${T.border}`, borderRadius: 8, fontSize: 12 }} formatter={(v) => fmtPct(v)} />
              </PieChart>
            </ResponsiveContainer>
            <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
              {statusData.map((d) => (
                <div key={d.name} style={{ display: "flex", alignItems: "center", gap: 8, fontSize: 12.5, color: T.textSecondary }}>
                  <span style={{ width: 9, height: 9, borderRadius: 2, background: STATUS_COLORS[d.name] || T.blue300 }} />
                  {d.name} <span className="mono" style={{ color: T.textPrimary, marginLeft: 2 }}>{fmtPct(d.value)}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="card" style={{ padding: "18px 20px 10px" }}>
          <div style={cardTitle}>Rocket status</div>
          <div style={cardSub}>Active vs. retired rocket types</div>
          <div style={{ display: "flex", alignItems: "center", gap: 16 }}>
            <ResponsiveContainer width={140} height={140}>
              <PieChart>
                <Pie data={rocketStatus} dataKey="value" nameKey="name" innerRadius={38} outerRadius={64} paddingAngle={2}>
                  {rocketStatus.map((d, i) => <Cell key={i} fill={STATUS_COLORS[d.name]} stroke={T.surface} strokeWidth={2} />)}
                </Pie>
                <Tooltip contentStyle={{ background: T.surfaceRaised, border: `1px solid ${T.border}`, borderRadius: 8, fontSize: 12 }} formatter={(v) => v.toLocaleString()} />
              </PieChart>
            </ResponsiveContainer>
            <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
              {rocketStatus.map((d) => (
                <div key={d.name} style={{ display: "flex", alignItems: "center", gap: 8, fontSize: 12.5, color: T.textSecondary }}>
                  <span style={{ width: 9, height: 9, borderRadius: 2, background: STATUS_COLORS[d.name] }} />
                  {d.name} <span className="mono" style={{ color: T.textPrimary, marginLeft: 2 }}>{d.value.toLocaleString()}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* top orgs + top years */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14, marginBottom: 14 }}>
        <div className="card" style={{ padding: "18px 20px 8px" }}>
          <div style={cardTitle}>Top 5 organisations by launches</div>
          <div style={cardSub}>RVSN USSR includes Cold War-era military launches</div>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={topOrgs} layout="vertical" margin={{ left: 10, right: 20, top: 0, bottom: 0 }}>
              <CartesianGrid stroke={T.border} horizontal={false} />
              <XAxis type="number" tick={{ fill: T.textMuted, fontSize: 11 }} axisLine={false} tickLine={false} />
              <YAxis type="category" dataKey="name" width={110} tick={{ fill: T.textSecondary, fontSize: 11 }} axisLine={false} tickLine={false} />
              <Tooltip contentStyle={{ background: T.surfaceRaised, border: `1px solid ${T.border}`, borderRadius: 8, fontSize: 12 }} formatter={(v) => [v.toLocaleString(), "Launches"]} />
              <Bar dataKey="launches" radius={[0, 4, 4, 0]} maxBarSize={16}>
                {topOrgs.map((_, i) => <Cell key={i} fill={[T.blue900, T.blue700, T.blue500, T.blue300, T.blue100][i]} />)}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="card" style={{ padding: "18px 20px 8px" }}>
          <div style={cardTitle}>Busiest years</div>
          <div style={cardSub}>Top 10 by mission count</div>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={topYears} layout="vertical" margin={{ left: 0, right: 20, top: 0, bottom: 0 }}>
              <CartesianGrid stroke={T.border} horizontal={false} />
              <XAxis type="number" tick={{ fill: T.textMuted, fontSize: 11 }} axisLine={false} tickLine={false} />
              <YAxis type="category" dataKey="year" width={40} tick={{ fill: T.textSecondary, fontSize: 11 }} axisLine={false} tickLine={false} />
              <Tooltip contentStyle={{ background: T.surfaceRaised, border: `1px solid ${T.border}`, borderRadius: 8, fontSize: 12 }} formatter={(v) => [v, "Missions"]} />
              <Bar dataKey="missions" fill={T.blue300} radius={[0, 4, 4, 0]} maxBarSize={13} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* top countries + org x decade heatmap */}
      <div style={{ display: "grid", gridTemplateColumns: "0.85fr 1.45fr", gap: 14, marginBottom: 14 }}>
        <div className="card" style={{ padding: "18px 20px 8px" }}>
          <div style={cardTitle}>Top 10 launch countries</div>
          <div style={cardSub}>By launch-site location</div>
          <ResponsiveContainer width="100%" height={280}>
            <BarChart data={topCountries} layout="vertical" margin={{ left: 10, right: 20, top: 0, bottom: 0 }}>
              <CartesianGrid stroke={T.border} horizontal={false} />
              <XAxis type="number" tick={{ fill: T.textMuted, fontSize: 10 }} axisLine={false} tickLine={false} />
              <YAxis type="category" dataKey="name" width={90} tick={{ fill: T.textSecondary, fontSize: 10.5 }} axisLine={false} tickLine={false} />
              <Tooltip contentStyle={{ background: T.surfaceRaised, border: `1px solid ${T.border}`, borderRadius: 8, fontSize: 12 }} formatter={(v) => [v.toLocaleString(), "Launches"]} />
              <Bar dataKey="launches" fill={T.blue300} radius={[0, 4, 4, 0]} maxBarSize={12} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="card" style={{ padding: "18px 20px" }}>
          <div style={cardTitle}>Launch volume: top 10 organisations x decade</div>
          <div style={cardSub}>Cell shade scales with launch count</div>
          <div style={{ overflowX: "auto" }}>
            <table>
              <thead>
                <tr>
                  <th className="rowlabel">Org</th>
                  {decades.map((d) => <th key={d}>{d}</th>)}
                </tr>
              </thead>
              <tbody>
                {orgDecadeHeatmap.map((row) => (
                  <tr key={row.org}>
                    <td className="rowlabel">{row.org}</td>
                    {row.counts.map((c, i) => (
                      <td key={i} className="mono" style={{ background: heatColor(c), color: c / heatMax > 0.35 ? "#fff" : T.textSecondary, borderRadius: 4 }}>
                        {c || ""}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* country share by decade + india decade */}
      <div style={{ display: "grid", gridTemplateColumns: "1.3fr 1fr", gap: 14, marginBottom: 14 }}>
        <div className="card" style={{ padding: "18px 20px 8px" }}>
          <div style={cardTitle}>Global launch share by decade</div>
          <div style={cardSub}>Approx. % of launches, top 6 countries</div>
          <ResponsiveContainer width="100%" height={210}>
            <BarChart data={countryDecadeShare} margin={{ left: -20, right: 10, top: 5, bottom: 0 }}>
              <CartesianGrid stroke={T.border} vertical={false} />
              <XAxis dataKey="decade" tick={{ fill: T.textMuted, fontSize: 11 }} axisLine={{ stroke: T.border }} tickLine={false} />
              <YAxis tick={{ fill: T.textMuted, fontSize: 11 }} axisLine={false} tickLine={false} unit="%" />
              <Tooltip contentStyle={{ background: T.surfaceRaised, border: `1px solid ${T.border}`, borderRadius: 8, fontSize: 12 }} />
              {shareKeys.map((k) => (
                <Bar key={k} dataKey={k} stackId="s" fill={shareColors[k]} />
              ))}
            </BarChart>
          </ResponsiveContainer>
          <div style={{ display: "flex", flexWrap: "wrap", gap: "6px 12px", marginTop: 4 }}>
            {shareKeys.map((k) => (
              <div key={k} style={{ display: "flex", alignItems: "center", gap: 6, fontSize: 11, color: T.textSecondary }}>
                <span style={{ width: 8, height: 8, borderRadius: 2, background: shareColors[k] }} />{k}
              </div>
            ))}
          </div>
        </div>

        <div className="card" style={{ padding: "18px 20px 8px" }}>
          <div style={cardTitle}>India's outcomes by decade</div>
          <div style={cardSub}>Mission count, stacked by result</div>
          <ResponsiveContainer width="100%" height={210}>
            <BarChart data={indiaDecade} margin={{ left: -20, right: 10, top: 5, bottom: 0 }}>
              <CartesianGrid stroke={T.border} vertical={false} />
              <XAxis dataKey="decade" tick={{ fill: T.textMuted, fontSize: 11 }} axisLine={{ stroke: T.border }} tickLine={false} />
              <YAxis tick={{ fill: T.textMuted, fontSize: 11 }} axisLine={false} tickLine={false} />
              <Tooltip contentStyle={{ background: T.surfaceRaised, border: `1px solid ${T.border}`, borderRadius: 8, fontSize: 12 }} />
              <Bar dataKey="Failure" stackId="i" fill={T.blue900} />
              <Bar dataKey="Partial failure" stackId="i" fill={T.blue500} />
              <Bar dataKey="Success" stackId="i" fill={T.blue100} radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* correlation heatmap */}
      <div className="card" style={{ padding: "18px 20px" }}>
        <div style={cardTitle}>Correlation heatmap</div>
        <div style={cardSub}>Year, price, and mission success</div>
        <div style={{ maxWidth: 420 }}>
          <table>
            <thead>
              <tr><th className="rowlabel" /> {corrLabels.map((l) => <th key={l}>{l}</th>)}</tr>
            </thead>
            <tbody>
              {corrMatrix.map((row, i) => (
                <tr key={i}>
                  <td className="rowlabel">{corrLabels[i]}</td>
                  {row.map((v, j) => (
                    <td key={j} className="mono" style={{ background: corrColor(v), color: Math.abs(v) > 0.3 ? "#fff" : T.textSecondary, borderRadius: 4, padding: "10px 4px" }}>
                      {v.toFixed(2)}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
