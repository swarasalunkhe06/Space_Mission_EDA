import SpaceMissionDashboard from './space-mission-dashboard';

function App() {
  return <SpaceMissionDashboard />;
}

export default App;